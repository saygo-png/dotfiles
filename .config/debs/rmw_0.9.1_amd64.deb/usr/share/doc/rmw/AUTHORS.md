# AUTHORS

GitHub's automated list: [graphs/contributors](https://github.com/andy5995/rmw/graphs/contributors)

## Contributors and Roles
| Name        | Roles
| :-----------: | ----------------------------------|
| Andy Alt | Project Manager |
| [Parth Suresh](https://github.com/parthsuresh) | C |
| [Bruce Hernandez](https://github.com/blah1898) | C |
| [suve](https://svgames.pl/en) | C |
| [Martijn de Boer](https://github.com/martijndeb) | NL translation, testing |
| [Ankur Jyoti Phukan](https://github.com/ajphukan) | C |
| [James Sherratt](https://github.com/Jammyjamjamman) | C |
| [Guillermo Franco](https://github.com/gfranco93) | man page |
| [João Rodrigues](https://github.com/jmrodriguesgoncalves) | PT translation |
| [Svitlana Galianova](https://github.com/svitlana-galianova) | RU & UK translation |
| [Mario Carrillo](https://github.com/marioecg) | Spanish (MX) translation |
| [Subhashree Mishra](https://github.com/Mishrasubha) | Hindi translation |
