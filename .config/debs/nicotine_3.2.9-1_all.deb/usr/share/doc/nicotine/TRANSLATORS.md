# Nicotine+ Translators

## Catalan
 - Maite Guix (2022)

## Chinese (Simplified)
 - hadwin (2022)

## Czech
 - burnmail123 (2021)

## Danish
 - mathsped (2003–2004)

## Dutch
 - Han Boetes (hboetes) (2021–2022)
 - Kenny Verstraete (2009)
 - nince78 (2007)
 - Ingmar K. Steen (Hyriand) (2003–2004)

## English
 - slook (2021–2022)
 - Han Boetes (hboetes) (2021–2022)
 - Mat (mathiascode) (2020–2022)
 - Michael Labouebe (gfarmerfr) (2016)
 - daelstorm (2004–2009)
 - Ingmar K. Steen (Hyriand) (2003–2004)

## Euskara
 - Julen (2006-2007)

## Finnish
 - Kari Viittanen (Kalevi) (2006–2007)

## French
 - Lisapple (2021–2022)
 - melmorabity (2021–2022)
 - m-balthazar (2020)
 - Michael Labouebe (gfarmerfr) (2016–2017)
 - Monsieur Poisson (2009–2010)
 - ManWell (2007)
 - zniavre (2007–2022)
 - systr (2006)
 - Julien Wajsberg (flashfr) (2003–2004)

## German
 - Han Boetes (hboetes) (2021–2022)
 - Meokater (2007)
 - (._.) (2007)
 - lippel (2004)
 - Ingmar K. Steen (Hyriand) (2003–2004)

## Hungarian
 - Szia Tomi (2022)
 - Nils (2009)
 - David Balazs (djbaloo) (2006–2020)

## Italian
 - Gabboxl (2022)
 - Gianluca Boiano (2020–2022)
 - nicola (2007)
 - dbazza (2003–2004)

## Latvian
 - Pagal3 (2022)

## Lithuanian
 - mantas (2020)
 - Žygimantas Beručka (2006–2009)

## Norwegian Bokmål
 - Allan Nordhøy (comradekingu) (2021)

## Polish
 - mariachini (2017–2022)
 - Amun-Ra (2007)
 - thine (2007)
 - Wojciech Owczarek (owczi) (2003–2004)

## Portuguese (Brazil)
 - Guilherme Santos (2022)
 - b1llso (2022)
 - Nicolas Abril (2021)
 - yyyyyyyan (2020)
 - Felipe Nogaroto Gonzalez (Suicide|Solution) (2006)

## Russian
 - AHOHNMYC (2022)
 - SnIPeRSnIPeR (2022)
 - Mehavoid (2021–2022)

## Slovak
 - Jozef Říha (2006–2008)

## Spanish (Chile)
 - MELERIX (2021–2022)
 - tagomago (2021–2022)
 - Strange (2021)
 - Silvio Orta (2007)
 - Dreslo (2003–2004)

## Spanish (Spain)
 - MELERIX (2021)
 - tagomago (2021–2022)
 - Strange (2021)
 - Silvio Orta (2007)
 - Dreslo (2003–2004)

## Swedish
 - mitramai (2021)
 - Markus Magnuson (alimony) (2003–2004)

## Turkish
 - Oğuz Ersen (2021–2022)

## Ukrainian
 - uniss2209 (2022)
